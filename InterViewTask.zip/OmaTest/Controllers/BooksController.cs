﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using OmaTest.Models;

namespace OmaTest.Controllers
{
    public class BooksController : Controller
    {
        private readonly BooklibraryContext _context;

        public BooksController(BooklibraryContext context)
        {
            _context = context;
        }

        // GET: Books
        public async Task<IActionResult> Index()
        {
            var booklibraryContext = _context.Books.Include(b => b.Shelf);
            return View(await booklibraryContext.ToListAsync());
        }

        /*public async Task<IActionResult> Index()
        {
            var books = await _context.Books.FromSqlRaw("EXECUTE GetBookDetails").ToListAsync();
            return View(books);
        }*/



        // GET: Books/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Books == null)
            {
                return NotFound();
            }

            var book = await _context.Books
                .Include(b => b.Shelf)
                .FirstOrDefaultAsync(m => m.Code == id);
            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }

        // GET: 
        public IActionResult Create()
        {
            ViewData["ShelfId"] = new SelectList(_context.Shelves, "ShelfId", "ShelfId");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        

        public async Task<IActionResult> Create([Bind("Code,BookName,Author,IsAvailable,Price,ShelfId")] Book book)
        {
            if (ModelState.IsValid)
            {
                _context.Database.ExecuteSqlRaw("EXEC dbo.AddBook @Code={0}, @BookName={1}, @Author={2}, @IsAvailable={3}, @Price={4}, @ShelfID={5}",
                    book.Code, book.BookName, book.Author, book.IsAvailable, book.Price, book.ShelfId);

                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            ViewData["ShelfId"] = new SelectList(_context.Shelves, "ShelfId", "ShelfId", book.ShelfId);
            return View(book);
        }


        // GET: Books/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Books == null)
            {
                return NotFound();
            }

            var book = await _context.Books.FindAsync(id);
            if (book == null)
            {
                return NotFound();
            }
            ViewData["ShelfId"] = new SelectList(_context.Shelves, "ShelfId", "ShelfId", book.ShelfId);
            return View(book);
        }

        // POST: Books/Edit/5
         [HttpPost]
        [ValidateAntiForgeryToken]


        public async Task<IActionResult> Edit(int id, [Bind("Code,BookName,Author,IsAvailable,Price,ShelfId")] Book book)
        {
            if (id != book.Code)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Database.ExecuteSqlRaw("EXEC UpdateBook @Code={0}, @BookName={1}, @Author={2}, "
                        + "@IsAvailable={3}, @Price={4}, @ShelfId={5}",
                        book.Code, book.BookName, book.Author, book.IsAvailable, book.Price, book.ShelfId);

                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BookExists(book.Code))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            ViewData["ShelfId"] = new SelectList(_context.Shelves, "Code", "Code", book.ShelfId);
            return View(book);
        }


        // GET: Books/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Books == null)
            {
                return NotFound();
            }

            var book = await _context.Books
                .Include(b => b.Shelf)
                .FirstOrDefaultAsync(m => m.Code == id);
            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }

        // POST: Books/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]


        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null)
            {
                return NotFound();
            }

            var connection = _context.Database.GetDbConnection();
            var command = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "SoftDeleteBook";
            command.Parameters.Add(new SqlParameter("@code", book.Code));

            await connection.OpenAsync();
            await command.ExecuteNonQueryAsync();
            await connection.CloseAsync();

            return RedirectToAction(nameof(Index));
        }



        private bool BookExists(int id)
        {
          return (_context.Books?.Any(e => e.Code == id)).GetValueOrDefault();
        }
    }
}
