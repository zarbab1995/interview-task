﻿using System;
using System.Collections.Generic;

namespace OmaTest.Models;

public partial class Rack
{
    public int RackId { get; set; }

    public string? Code { get; set; }

    public virtual ICollection<Shelf> Shelves { get; set; } = new List<Shelf>();
}
